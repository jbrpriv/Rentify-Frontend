'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import api from '@/utils/api';
import {
  LayoutDashboard, Building2, FileText, Users, Key, User, Loader2,
  ShieldCheck, Wrench, MessageSquare, CreditCard, BarChart2, Scale,
  ClipboardList, X,
} from 'lucide-react';

const NAV_BY_ROLE = {
  landlord: [
    { name: 'Overview',     href: '/dashboard',                  icon: LayoutDashboard },
    { name: 'Properties',   href: '/dashboard/properties',       icon: Building2 },
    { name: 'Applications', href: '/dashboard/applications',     icon: Users,         badgeKey: 'applications' },
    { name: 'Agreements',   href: '/dashboard/agreements',       icon: FileText,      badgeKey: 'agreements' },
    { name: 'Tenants',      href: '/dashboard/landlord/tenants', icon: Users },
    { name: 'Maintenance',  href: '/dashboard/maintenance',      icon: Wrench,        badgeKey: 'maintenance' },
    { name: 'Messages',     href: '/dashboard/messages',         icon: MessageSquare, badgeKey: 'messages' },
    { name: 'Disputes',     href: '/dashboard/disputes',         icon: Scale },
    { name: 'Profile',      href: '/dashboard/profile',          icon: User },
  ],
  tenant: [
    { name: 'Overview',    href: '/dashboard',             icon: LayoutDashboard },
    { name: 'My Lease',    href: '/dashboard/my-lease',    icon: Key },
    { name: 'Payments',    href: '/dashboard/payments',    icon: CreditCard },
    { name: 'Maintenance', href: '/dashboard/maintenance', icon: Wrench,        badgeKey: 'maintenance' },
    { name: 'Disputes',    href: '/dashboard/disputes',    icon: Scale },
    { name: 'Messages',    href: '/dashboard/messages',    icon: MessageSquare, badgeKey: 'messages' },
    { name: 'Profile',     href: '/dashboard/profile',     icon: User },
  ],
  admin: [
    { name: 'Overview',    href: '/dashboard',                  icon: LayoutDashboard },
    { name: 'Stats',       href: '/dashboard/admin',            icon: BarChart2 },
    { name: 'Users',       href: '/dashboard/admin/users',      icon: Users },
    { name: 'Agreements',  href: '/dashboard/admin/agreements', icon: FileText },
    { name: 'Properties',  href: '/dashboard/admin/properties', icon: Building2 },
    { name: 'Templates',   href: '/dashboard/admin/templates',  icon: ClipboardList },
    { name: 'Disputes',    href: '/dashboard/disputes',         icon: Scale },
    { name: 'Messages',    href: '/dashboard/messages',         icon: MessageSquare, badgeKey: 'messages' },
    { name: 'Audit Logs',  href: '/dashboard/admin/audit-logs', icon: ShieldCheck },
    { name: 'Profile',     href: '/dashboard/profile',          icon: User },
  ],
  property_manager: [
    { name: 'Overview',    href: '/dashboard',                icon: LayoutDashboard },
    { name: 'Properties',  href: '/dashboard/pm/properties',  icon: Building2 },
    { name: 'Tenants',     href: '/dashboard/pm/tenants',     icon: Users },
    { name: 'Maintenance', href: '/dashboard/pm/maintenance', icon: Wrench,        badgeKey: 'maintenance' },
    { name: 'Messages',    href: '/dashboard/messages',       icon: MessageSquare, badgeKey: 'messages' },
    { name: 'Profile',     href: '/dashboard/profile',        icon: User },
  ],
  law_reviewer: [
    { name: 'Overview',   href: '/dashboard',                 icon: LayoutDashboard },
    { name: 'Templates',  href: '/dashboard/admin/templates', icon: Scale },
    { name: 'Agreements', href: '/dashboard/agreements',      icon: FileText,      badgeKey: 'agreements' },
    { name: 'Messages',   href: '/dashboard/messages',        icon: MessageSquare, badgeKey: 'messages' },
    { name: 'Profile',    href: '/dashboard/profile',         icon: User },
  ],
};

const ROLE_PULSE = {
  admin: 'bg-red-500', landlord: 'bg-indigo-500',
  property_manager: 'bg-amber-500', tenant: 'bg-green-500', law_reviewer: 'bg-purple-500',
};
const ROLE_BADGE = {
  admin: 'bg-red-100 text-red-700', landlord: 'bg-indigo-100 text-indigo-700',
  property_manager: 'bg-amber-100 text-amber-700', tenant: 'bg-green-100 text-green-700',
  law_reviewer: 'bg-purple-100 text-purple-700',
};
const ROLE_COLORS = {
  landlord:        { bg: 'bg-indigo-100', text: 'text-indigo-700' },
  tenant:          { bg: 'bg-emerald-100', text: 'text-emerald-700' },
  property_manager:{ bg: 'bg-amber-100',  text: 'text-amber-700'  },
  admin:           { bg: 'bg-rose-100',   text: 'text-rose-700'   },
  law_reviewer:    { bg: 'bg-violet-100', text: 'text-violet-700' },
};

// ── Notification Toast ─────────────────────────────────────────────────────────
function NotificationToast({ notification, onDismiss }) {
  const [show, setShow] = useState(false);
  const router = useRouter();

  useEffect(() => {
    if (!notification) return;
    const t1 = setTimeout(() => setShow(true), 10);
    const t2 = setTimeout(() => { setShow(false); setTimeout(onDismiss, 400); }, 5000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [notification, onDismiss]);

  if (!notification) return null;

  const c = ROLE_COLORS[notification.senderRole] || { bg: 'bg-slate-100', text: 'text-slate-600' };

  return (
    <div
      onClick={() => {
        setShow(false);
        setTimeout(() => { onDismiss(); router.push('/dashboard/messages'); }, 200);
      }}
      className="fixed top-20 right-4 z-[200] cursor-pointer"
      style={{
        transition: 'all 400ms cubic-bezier(0.34, 1.56, 0.64, 1)',
        transform: show ? 'translateX(0) scale(1)' : 'translateX(110%) scale(0.9)',
        opacity: show ? 1 : 0,
      }}
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 flex items-start gap-3 w-80">
        <div className={`w-10 h-10 ${c.bg} ${c.text} rounded-2xl flex items-center justify-center font-black flex-shrink-0 text-sm`}>
          {notification.senderName?.charAt(0)?.toUpperCase() || '?'}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-0.5">
            <p className="text-sm font-black text-gray-900 truncate">{notification.senderName}</p>
            <button onClick={e => { e.stopPropagation(); setShow(false); setTimeout(onDismiss, 400); }}>
              <X className="w-3.5 h-3.5 text-gray-300 hover:text-gray-500" />
            </button>
          </div>
          <p className="text-xs text-gray-500 truncate">{notification.preview}</p>
          {notification.propertyTitle && (
            <p className="text-[10px] text-gray-300 mt-0.5 truncate">{notification.propertyTitle}</p>
          )}
          <p className="text-[10px] text-blue-400 font-semibold mt-1">Tap to open messages →</p>
        </div>
      </div>
      <span className="absolute -top-1 -right-1 flex h-4 w-4">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75" />
        <span className="relative inline-flex rounded-full h-4 w-4 bg-blue-500" />
      </span>
    </div>
  );
}

export default function DashboardLayout({ children }) {
  const router   = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState(null);
  const [badgeCounts, setBadgeCounts] = useState({});
  const [notification, setNotification] = useState(null);
  const socketRef = useRef(null);

  const fetchCounts = useCallback(async () => {
    try {
      const { data } = await api.get('/notifications/counts');
      setBadgeCounts(data);
    } catch { /* badge counts are non-critical */ }
  }, []);

  useEffect(() => {
    const stored = localStorage.getItem('userInfo');
    if (!stored) { router.push('/login'); return; }
    const u = JSON.parse(stored);
    setUser(u);
    fetchCounts();

    // ── Socket: one persistent connection for entire dashboard session ──
    const SOCKET_URL = process.env.NEXT_PUBLIC_API_URL?.replace('/api', '') || 'http://localhost:5000';
    import('socket.io-client').then(({ io }) => {
      const socket = io(SOCKET_URL, { transports: ['websocket', 'polling'] });
      socketRef.current = socket;

      socket.on('connect', () => socket.emit('register', u._id));

      socket.on('new_message', (msg) => {
        // Refresh badge counts
        fetchCounts();
        // Notify messages page to refresh its inbox list
        window.dispatchEvent(new CustomEvent('dashboard:new_message', { detail: msg }));
        // Show toast only for incoming (not own) messages AND only when that chat is NOT open
        const sId = String(msg.sender?._id || msg.sender);
        const isOwnMessage = sId === String(u._id);
        const isChatOpen = window.__activeChatUserId && window.__activeChatUserId === sId;
        if (!isOwnMessage && !isChatOpen) {
          setNotification({
            senderName: msg.sender?.name || 'Someone',
            senderRole: msg.sender?.role,
            preview: msg.content?.length > 60 ? msg.content.slice(0, 60) + '…' : msg.content,
            propertyTitle: msg.property?.title,
          });
        }
      });
    });

    const interval = setInterval(fetchCounts, 120_000);
    // Refresh badge counts immediately when a chat marks messages as read
    const handleRefreshCounts = () => fetchCounts();
    window.addEventListener('dashboard:refresh_counts', handleRefreshCounts);
    return () => {
      clearInterval(interval);
      window.removeEventListener('dashboard:refresh_counts', handleRefreshCounts);
      socketRef.current?.disconnect();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Refresh counts on every route change
  useEffect(() => {
    if (pathname) fetchCounts();
  }, [pathname, fetchCounts]);

  if (!user) return (
    <div className="h-screen flex items-center justify-center bg-white">
      <Loader2 className="animate-spin h-10 w-10 text-blue-600" />
    </div>
  );

  const role       = user.role || 'tenant';
  const currentNav = NAV_BY_ROLE[role] || NAV_BY_ROLE.tenant;
  const pulseColor = ROLE_PULSE[role] || 'bg-gray-400';
  const badgeColor = ROLE_BADGE[role]  || 'bg-gray-100 text-gray-600';
  const roleLabel  = role.replace('_', ' ');

  return (
    <div className="min-h-screen flex flex-col bg-[#fcfcfd]">
      <Navbar />

      {/* Global notification toast — shows on any dashboard page */}
      <NotificationToast
        notification={notification}
        onDismiss={() => setNotification(null)}
      />

      {/* DASHBOARD SUB-NAV BAR */}
      <div className="mt-16 bg-white border-b border-gray-100 sticky top-16 z-40 w-full shadow-sm">
        <div className="w-full px-4 sm:px-8 lg:px-12">
          <div className="flex items-center justify-between h-14">
            <div className="flex space-x-1 overflow-x-auto no-scrollbar h-full items-center">
              {currentNav.map((item) => {
                const Icon = item.icon;
                const isActive =
                  pathname === item.href ||
                  (item.href !== '/dashboard' && pathname.startsWith(item.href));
                const count = item.badgeKey ? (badgeCounts[item.badgeKey] || 0) : 0;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`relative flex items-center h-full px-3 text-[10px] font-black uppercase tracking-widest border-b-2 transition-all whitespace-nowrap ${
                      isActive
                        ? 'border-blue-600 text-blue-600'
                        : 'border-transparent text-gray-400 hover:text-gray-600 hover:border-gray-200'
                    }`}
                  >
                    <Icon className={`mr-1.5 h-3.5 w-3.5 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
                    {item.name}
                    {count > 0 && (
                      <span className="ml-1.5 inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full bg-blue-600 text-white text-[9px] font-black leading-none">
                        {count > 9 ? '9+' : count}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
            <div className="hidden sm:flex items-center gap-2 ml-4 shrink-0">
              <div className={`w-2 h-2 rounded-full animate-pulse ${pulseColor}`} />
              <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full tracking-widest ${badgeColor}`}>
                {roleLabel}
              </span>
            </div>
          </div>
        </div>
      </div>

      <main className="flex-grow py-10 px-4 sm:px-8 lg:px-12 w-full max-w-[1600px] mx-auto">
        {children}
      </main>
      <Footer />
    </div>
  );
}