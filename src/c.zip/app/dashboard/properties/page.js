'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import api from '@/utils/api';
import {
  Building2, MapPin, Plus, FileText, Loader2, UserPlus,
  CheckCircle, Clock, Eye, EyeOff, X, AlertTriangle
} from 'lucide-react';

// ── Publish/Unpublish Confirmation Modal ────────────────────────────────────
function PublishModal({ property, onConfirm, onCancel, loading }) {
  const publishing = !property.isListed;
  return (
    <>
      <style>{`
        .pm-overlay {
          position: fixed; inset: 0; background: rgba(15,23,42,0.55);
          backdrop-filter: blur(4px); z-index: 1000;
          display: flex; align-items: center; justify-content: center; padding: 20px;
          animation: pmFadeIn 0.18s ease;
        }
        @keyframes pmFadeIn { from { opacity: 0; } to { opacity: 1; } }
        .pm-card {
          background: white; border-radius: 24px; padding: 36px 32px;
          max-width: 420px; width: 100%;
          box-shadow: 0 24px 80px rgba(15,23,42,0.2);
          animation: pmSlideUp 0.22s cubic-bezier(0.34,1.2,0.64,1);
        }
        @keyframes pmSlideUp {
          from { opacity: 0; transform: translateY(28px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
      <div className="pm-overlay" onClick={onCancel}>
        <div className="pm-card" onClick={e => e.stopPropagation()}>
          {/* Icon */}
          <div style={{
            width: 60, height: 60, borderRadius: 18, margin: '0 auto 20px',
            background: publishing ? 'linear-gradient(135deg,#DCFCE7,#BBF7D0)' : 'linear-gradient(135deg,#FEF2F2,#FECACA)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {publishing
              ? <Eye size={26} style={{color:'#16A34A'}}/>
              : <EyeOff size={26} style={{color:'#DC2626'}}/>
            }
          </div>

          {/* Title */}
          <h2 style={{fontFamily:"'Outfit',sans-serif", fontWeight:800, fontSize:'1.3rem', color:'#0F172A', textAlign:'center', marginBottom:8, letterSpacing:'-0.02em'}}>
            {publishing ? 'Publish Listing?' : 'Unpublish Listing?'}
          </h2>

          {/* Property name */}
          <p style={{textAlign:'center', color:'#64748B', fontSize:'0.85rem', marginBottom:20}}>
            <span style={{fontWeight:700, color:'#0F172A'}}>{property.title}</span>
            <br/>
            <span style={{fontSize:'0.8rem'}}>{property.address?.city}, {property.address?.state}</span>
          </p>

          {/* Info box */}
          <div style={{
            background: publishing ? '#F0FDF4' : '#FFF7F7',
            border: `1px solid ${publishing ? '#BBF7D0' : '#FECACA'}`,
            borderRadius: 12, padding: '12px 16px', marginBottom: 24,
            display: 'flex', alignItems: 'flex-start', gap: 10,
          }}>
            <AlertTriangle size={15} style={{color: publishing ? '#16A34A' : '#DC2626', flexShrink:0, marginTop:1}}/>
            <p style={{fontSize:'0.8rem', color: publishing ? '#166534' : '#991B1B', lineHeight:1.6}}>
              {publishing
                ? 'This property will be visible to tenants on the marketplace. They can browse, view details, and submit applications.'
                : 'This property will be hidden from the marketplace. Existing applications will remain unaffected.'
              }
            </p>
          </div>

          {/* Buttons */}
          <div style={{display:'flex', gap:10}}>
            <button onClick={onCancel} disabled={loading}
              style={{flex:1, padding:'12px', border:'1.5px solid #E2E8F0', borderRadius:12, fontSize:'0.875rem', fontWeight:700, color:'#64748B', background:'white', cursor:'pointer', fontFamily:"'Plus Jakarta Sans',sans-serif"}}>
              Cancel
            </button>
            <button onClick={onConfirm} disabled={loading}
              style={{
                flex:1.5, padding:'12px', border:'none', borderRadius:12, fontSize:'0.875rem', fontWeight:700, color:'white', cursor: loading ? 'not-allowed' : 'pointer',
                background: publishing ? 'linear-gradient(135deg,#16A34A,#22C55E)' : 'linear-gradient(135deg,#DC2626,#EF4444)',
                display:'flex', alignItems:'center', justifyContent:'center', gap:7,
                fontFamily:"'Outfit',sans-serif",
                boxShadow: publishing ? '0 4px 14px rgba(22,163,74,0.3)' : '0 4px 14px rgba(220,38,38,0.3)',
              }}>
              {loading ? <Loader2 size={15} className="animate-spin"/> : publishing ? <Eye size={15}/> : <EyeOff size={15}/>}
              {loading ? 'Please wait...' : publishing ? 'Yes, Publish' : 'Yes, Unpublish'}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default function PropertiesPage() {
  const router = useRouter();
  useEffect(() => {
    const stored = localStorage.getItem('userInfo');
    if (!stored) { router.push('/login'); return; }
    const parsed = JSON.parse(stored);
    if (!['landlord','admin'].includes(parsed.role)) { router.push('/dashboard'); return; }
  }, []);

  const [properties, setProperties] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [inviting, setInviting]     = useState('');
  const [msg, setMsg]               = useState('');
  const [publishModal, setPublishModal] = useState(null); // { property }
  const [publishLoading, setPublishLoading] = useState(false);

  const fetchProperties = async () => {
    try { const { data } = await api.get('/properties'); setProperties(data); }
    catch (error) { console.error(error); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchProperties(); }, []);

  const handleTogglePublish = (property) => {
    setPublishModal({ property });
  };

  const confirmPublish = async () => {
    if (!publishModal) return;
    const { property } = publishModal;
    setPublishLoading(true);
    try {
      await api.put(`/listings/${property._id}/publish`, { listingDescription: property.listingDescription || '' });
      fetchProperties();
      setPublishModal(null);
    } catch (err) {
      setMsg('❌ Failed to update listing status');
      setTimeout(() => setMsg(''), 4000);
      setPublishModal(null);
    } finally {
      setPublishLoading(false);
    }
  };

  const handleInviteManager = async (propertyId) => {
    const email = window.prompt('Enter the property manager\'s email address:');
    if (!email) return;
    setInviting(propertyId);
    try {
      const { data: pmUser } = await api.post('/users/lookup', { email });
      if (pmUser.role !== 'property_manager') {
        setMsg(`❌ ${pmUser.name} is a ${pmUser.role}, not a property manager.`);
        setTimeout(() => setMsg(''), 5000);
        setInviting('');
        return;
      }
      await api.post(`/properties/${propertyId}/invite-manager`, { managerId: pmUser._id });
      setMsg('✅ Invitation sent! The property manager will be notified by email.');
      setTimeout(() => setMsg(''), 5000);
      fetchProperties();
    } catch (err) {
      setMsg('❌ ' + (err.response?.data?.message || 'Failed to send invitation'));
      setTimeout(() => setMsg(''), 5000);
    } finally { setInviting(''); }
  };

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:400}}>
      <Loader2 className="animate-spin" style={{width:32,height:32,color:'#2563EB'}}/>
    </div>
  );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        .prop-card { background:white; border-radius:20px; border:1px solid #E2E8F0; overflow:hidden; box-shadow:0 1px 6px rgba(15,23,42,0.06); transition:box-shadow 0.2s, transform 0.2s; }
        .prop-card:hover { box-shadow:0 8px 28px rgba(15,23,42,0.1); transform:translateY(-2px); }
        .prop-img { width:100%; height:140px; object-fit:cover; }
        .prop-img-placeholder { width:100%; height:140px; background:linear-gradient(135deg,#EFF6FF,#DBEAFE); display:flex; align-items:center; justify-content:center; }
        .action-btn { display:inline-flex; align-items:center; justify-content:center; gap:5px; padding:8px 14px; border-radius:10px; font-size:0.78rem; font-weight:700; cursor:pointer; border:none; transition:all 0.15s; font-family:'Plus Jakarta Sans',sans-serif; }
      `}</style>

      {publishModal && (
        <PublishModal
          property={publishModal.property}
          onConfirm={confirmPublish}
          onCancel={() => setPublishModal(null)}
          loading={publishLoading}
        />
      )}

      <div style={{display:'flex',flexDirection:'column',gap:24}}>

        {/* Header */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div>
            <h1 style={{fontFamily:"'Outfit',sans-serif",fontWeight:800,fontSize:'1.8rem',color:'#0F172A',letterSpacing:'-0.02em',lineHeight:1}}>My Properties</h1>
            <p style={{color:'#94A3B8',fontSize:'0.83rem',marginTop:4}}>{properties.length} propert{properties.length === 1 ? 'y' : 'ies'} in your portfolio</p>
          </div>
          <Link href="/dashboard/properties/new"
            style={{display:'inline-flex',alignItems:'center',gap:8,padding:'10px 18px',background:'linear-gradient(135deg,#1D4ED8,#3B82F6)',color:'white',borderRadius:12,fontSize:'0.85rem',fontWeight:700,textDecoration:'none',boxShadow:'0 4px 14px rgba(37,99,235,0.25)',fontFamily:"'Outfit',sans-serif"}}>
            <Plus size={16}/> Add Property
          </Link>
        </div>

        {/* Toast */}
        {msg && (
          <div style={{borderRadius:12,padding:'12px 18px',fontSize:'0.875rem',fontWeight:600,display:'flex',alignItems:'center',gap:10,
            background: msg.startsWith('✅') ? '#F0FDF4' : '#FFF7F7',
            color: msg.startsWith('✅') ? '#16A34A' : '#DC2626',
            border: `1px solid ${msg.startsWith('✅') ? '#BBF7D0' : '#FECACA'}`,
          }}>
            {msg.startsWith('✅') ? <CheckCircle size={16}/> : <X size={16}/>} {msg.slice(2)}
          </div>
        )}

        {/* Empty */}
        {properties.length === 0 ? (
          <div style={{textAlign:'center',padding:'56px 20px',background:'white',borderRadius:20,border:'2px dashed #E2E8F0'}}>
            <Building2 size={44} style={{color:'#CBD5E1',margin:'0 auto 12px'}}/>
            <h3 style={{fontFamily:"'Outfit',sans-serif",fontWeight:700,color:'#475569',fontSize:'1.1rem'}}>No properties yet</h3>
            <p style={{color:'#94A3B8',fontSize:'0.85rem',marginTop:4,marginBottom:20}}>Create your first property to start managing tenants and leases.</p>
            <Link href="/dashboard/properties/new"
              style={{display:'inline-flex',alignItems:'center',gap:6,padding:'10px 20px',background:'#2563EB',color:'white',borderRadius:10,fontSize:'0.85rem',fontWeight:700,textDecoration:'none'}}>
              <Plus size={15}/> Add Your First Property
            </Link>
          </div>
        ) : (
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:18}}>
            {properties.map(property => {
              const invStatus = property.pmInvitation?.status;
              const hasPendingInvite = invStatus === 'pending';
              const hasManager = !!property.managedBy;
              const heroImg = property.images?.[0];

              const statusColors = {
                vacant:      { bg:'#EFF6FF', color:'#2563EB' },
                occupied:    { bg:'#F0FDF4', color:'#16A34A' },
                maintenance: { bg:'#FFFBEB', color:'#D97706' },
              };
              const sc = statusColors[property.status] || statusColors.vacant;

              return (
                <div key={property._id} className="prop-card">
                  {/* Cover image */}
                  {heroImg
                    ? <img src={heroImg} alt={property.title} className="prop-img"/>
                    : <div className="prop-img-placeholder"><Building2 size={32} style={{color:'#93C5FD'}}/></div>
                  }

                  <div style={{padding:'16px 18px'}}>
                    {/* Status badges */}
                    <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:8}}>
                      <span style={{padding:'3px 10px',borderRadius:20,fontSize:'0.7rem',fontWeight:700,background:sc.bg,color:sc.color,textTransform:'capitalize'}}>
                        {property.status}
                      </span>
                      {property.isListed && (
                        <span style={{padding:'3px 10px',borderRadius:20,fontSize:'0.7rem',fontWeight:700,background:'#EDE9FE',color:'#7C3AED'}}>
                          Listed
                        </span>
                      )}
                    </div>

                    {/* Title & location */}
                    <h3 style={{fontFamily:"'Outfit',sans-serif",fontWeight:700,fontSize:'1rem',color:'#0F172A',marginBottom:4,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                      {property.title}
                    </h3>
                    <p style={{display:'flex',alignItems:'center',gap:4,color:'#94A3B8',fontSize:'0.8rem',marginBottom:14}}>
                      <MapPin size={12}/> {property.address?.city}, {property.address?.state}
                    </p>

                    {/* Stats */}
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:14,paddingTop:14,borderTop:'1px solid #F1F5F9'}}>
                      <div>
                        <p style={{fontSize:'0.67rem',fontWeight:700,color:'#94A3B8',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:2}}>Monthly Rent</p>
                        <p style={{fontFamily:"'Outfit',sans-serif",fontWeight:800,fontSize:'1.05rem',color:'#0F172A'}}>Rs. {property.financials?.monthlyRent?.toLocaleString()}</p>
                      </div>
                      <div>
                        <p style={{fontSize:'0.67rem',fontWeight:700,color:'#94A3B8',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:2}}>Type</p>
                        <p style={{fontWeight:600,fontSize:'0.875rem',color:'#374151',textTransform:'capitalize'}}>{property.type}</p>
                      </div>
                    </div>

                    {/* PM Status */}
                    {hasManager ? (
                      <div style={{display:'flex',alignItems:'center',gap:6,background:'#F0FDF4',border:'1px solid #BBF7D0',borderRadius:8,padding:'7px 10px',marginBottom:14}}>
                        <CheckCircle size={13} style={{color:'#16A34A'}}/>
                        <span style={{fontSize:'0.75rem',fontWeight:700,color:'#166534'}}>Managed by: {property.managedBy?.name || 'PM'}</span>
                      </div>
                    ) : hasPendingInvite ? (
                      <div style={{display:'flex',alignItems:'center',gap:6,background:'#FFFBEB',border:'1px solid #FDE68A',borderRadius:8,padding:'7px 10px',marginBottom:14}}>
                        <Clock size={13} style={{color:'#D97706'}}/>
                        <span style={{fontSize:'0.75rem',fontWeight:700,color:'#92400E'}}>Invitation sent — awaiting PM response</span>
                      </div>
                    ) : (
                      <p style={{fontSize:'0.75rem',color:'#CBD5E1',marginBottom:14}}>No property manager assigned</p>
                    )}

                    {/* Actions */}
                    <div style={{display:'flex',flexWrap:'wrap',gap:7,paddingTop:14,borderTop:'1px solid #F1F5F9'}}>
                      <Link href={`/dashboard/properties/edit?id=${property._id}`}
                        className="action-btn" style={{background:'#F8FAFC',color:'#475569',border:'1.5px solid #E2E8F0',textDecoration:'none'}}>
                        Edit
                      </Link>

                      {property.status !== 'occupied' && (
                        <button onClick={() => handleTogglePublish(property)}
                          className="action-btn"
                          style={{
                            flex:1, background: property.isListed ? '#FFF7F7' : '#F0FDF4',
                            color: property.isListed ? '#DC2626' : '#16A34A',
                            border: `1.5px solid ${property.isListed ? '#FECACA' : '#BBF7D0'}`,
                          }}>
                          {property.isListed ? <><EyeOff size={13}/> Unpublish</> : <><Eye size={13}/> Publish</>}
                        </button>
                      )}

                      <Link href={`/dashboard/agreements/new?propertyId=${property._id}`}
                        className="action-btn" style={{background:'#EFF6FF',color:'#2563EB',border:'1.5px solid #BFDBFE',textDecoration:'none'}}>
                        <FileText size={13}/> Agreement
                      </Link>

                      {!hasManager && !hasPendingInvite && (
                        <button onClick={() => handleInviteManager(property._id)} disabled={inviting === property._id}
                          className="action-btn"
                          style={{flex:1,background:'#F5F3FF',color:'#7C3AED',border:'1.5px solid #DDD6FE'}}>
                          {inviting === property._id ? <Loader2 size={13} className="animate-spin"/> : <UserPlus size={13}/>}
                          Invite PM
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}