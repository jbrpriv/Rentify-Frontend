'use client';

import { useEffect, useState, Suspense } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import api from '@/utils/api';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import {
  MapPin, Bed, Bath, SquareCode, ShieldCheck, ArrowLeft,
  Loader2, FileText, ChevronLeft, ChevronRight,
  CheckCircle, Eye, Clock, Heart, PawPrint, Home,
  X, Images, Tag, Wrench, Send, DollarSign,
} from 'lucide-react';

// ── Tour date helpers ──────────────────────────────────────────────────────────
function getTourDates(count = 10) {
  const days   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const today  = new Date();
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    return { day: days[d.getDay()], num: d.getDate(), month: months[d.getMonth()] };
  });
}

// ── Gallery Modal ──────────────────────────────────────────────────────────────
function GalleryModal({ images, onClose }) {
  const [idx, setIdx] = useState(0);
  const prev = () => setIdx(i => (i - 1 + images.length) % images.length);
  const next = () => setIdx(i => (i + 1) % images.length);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'ArrowLeft')  prev();
      if (e.key === 'ArrowRight') next();
      if (e.key === 'Escape')     onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []); // eslint-disable-line

  return (
    <div style={{
      position:'fixed',inset:0,background:'rgba(0,0,0,0.94)',zIndex:2000,
      display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
    }} onClick={onClose}>
      {/* Close */}
      <button onClick={onClose} style={{
        position:'absolute',top:18,right:18,background:'rgba(255,255,255,0.1)',
        border:'none',color:'white',borderRadius:'50%',width:40,height:40,
        display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',zIndex:10,
      }}><X size={20}/></button>

      {/* Counter */}
      <p style={{position:'absolute',top:22,left:'50%',transform:'translateX(-50%)',
        color:'rgba(255,255,255,0.65)',fontSize:'0.82rem',fontWeight:600,pointerEvents:'none'}}>
        {idx + 1} / {images.length}
      </p>

      {/* Main image + arrows */}
      <div onClick={e => e.stopPropagation()}
        style={{display:'flex',alignItems:'center',gap:12,width:'100%',maxWidth:1000,padding:'0 16px'}}>
        <button onClick={prev} style={{background:'rgba(255,255,255,0.1)',border:'none',color:'white',
          borderRadius:12,width:44,height:44,display:'flex',alignItems:'center',justifyContent:'center',
          cursor:'pointer',flexShrink:0,transition:'background 0.15s'}}
          onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,0.2)'}
          onMouseLeave={e=>e.currentTarget.style.background='rgba(255,255,255,0.1)'}>
          <ChevronLeft size={22}/>
        </button>
        <img src={images[idx]} alt={`Photo ${idx+1}`}
          style={{flex:1,maxHeight:'72vh',objectFit:'contain',borderRadius:14}}/>
        <button onClick={next} style={{background:'rgba(255,255,255,0.1)',border:'none',color:'white',
          borderRadius:12,width:44,height:44,display:'flex',alignItems:'center',justifyContent:'center',
          cursor:'pointer',flexShrink:0,transition:'background 0.15s'}}
          onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,0.2)'}
          onMouseLeave={e=>e.currentTarget.style.background='rgba(255,255,255,0.1)'}>
          <ChevronRight size={22}/>
        </button>
      </div>

      {/* Thumbnail strip */}
      <div onClick={e=>e.stopPropagation()}
        style={{display:'flex',gap:8,marginTop:16,padding:'0 16px',overflowX:'auto',maxWidth:'100%'}}>
        {images.map((img, i) => (
          <img key={i} src={img} alt="" onClick={() => setIdx(i)}
            style={{
              width:68,height:50,objectFit:'cover',borderRadius:8,cursor:'pointer',flexShrink:0,
              border: i === idx ? '2px solid #3B82F6' : '2px solid transparent',
              opacity: i === idx ? 1 : 0.55, transition:'all 0.15s',
            }}/>
        ))}
      </div>
    </div>
  );
}

// ── Multi-step Offer Wizard Modal ─────────────────────────────────────────────
function OfferWizard({ listing, onSubmit, onCancel, applying }) {
  const [step, setStep] = useState(0);

  // Defaults from listing
  const listedRent    = listing?.financials?.monthlyRent    || '';
  const listedDeposit = listing?.financials?.securityDeposit || '';

  const [rentOffer,     setRent]     = useState({ proposed: String(listedRent),    message: '' });
  const [securityOffer, setSecurity] = useState({ proposed: String(listedDeposit), message: '' });
  const [maintOffer,    setMaint]    = useState({ scope: '', reduction: '', message: '' });

  const STEPS = [
    { label: 'Rent Offer',        subtitle: 'Step 1 of 4', color: '#2563EB', bg: '#EFF6FF', icon: Tag         },
    { label: 'Security Deposit',  subtitle: 'Step 2 of 4', color: '#7C3AED', bg: '#F5F3FF', icon: ShieldCheck  },
    { label: 'Maintenance Offer', subtitle: 'Step 3 of 4', color: '#059669', bg: '#F0FDF4', icon: Wrench       },
    { label: 'Review & Submit',   subtitle: 'Step 4 of 4', color: '#0F172A', bg: '#F8FAFC', icon: Send         },
  ];

  const s = STEPS[step];
  const Icon = s.icon;
  const progress = ((step + 1) / 4) * 100;

  const inp = (accentColor) => ({
    width:'100%', padding:'10px 14px', border:'1.5px solid #E2E8F0',
    borderRadius:10, fontSize:'0.875rem', outline:'none',
    fontFamily:"'Plus Jakarta Sans',sans-serif", color:'#0F172A',
    background:'#FAFBFF', boxSizing:'border-box', transition:'border-color 0.2s',
  });
  const lbl = {
    display:'block', fontSize:'0.72rem', fontWeight:700, color:'#64748B',
    textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:6,
  };
  const focus = (color) => ({
    onFocus: e => e.target.style.borderColor = color,
    onBlur:  e => e.target.style.borderColor = '#E2E8F0',
  });

  const reviewRow = (label, value, color) => (
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',
      padding:'10px 0',borderBottom:'1px solid #F1F5F9',gap:12}}>
      <span style={{color:'#64748B',fontSize:'0.82rem',fontWeight:600,flexShrink:0}}>{label}</span>
      <span style={{color:color||'#0F172A',fontWeight:700,fontSize:'0.82rem',textAlign:'right'}}>{value || '—'}</span>
    </div>
  );

  return (
    <div style={{
      position:'fixed',inset:0,background:'rgba(15,23,42,0.65)',backdropFilter:'blur(5px)',
      zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:16,
    }}>
      <div style={{background:'white',borderRadius:22,width:'100%',maxWidth:460,
        boxShadow:'0 24px 64px rgba(15,23,42,0.28)',overflow:'hidden'}}>

        {/* Header */}
        <div style={{background:s.bg,padding:'18px 22px 16px',borderBottom:'1px solid #F1F5F9'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <div style={{width:36,height:36,borderRadius:10,background:`${s.color}20`,
                display:'flex',alignItems:'center',justifyContent:'center'}}>
                <Icon size={17} style={{color:s.color}}/>
              </div>
              <div>
                <p style={{fontSize:'0.63rem',fontWeight:700,color:s.color,
                  textTransform:'uppercase',letterSpacing:'0.09em',margin:0}}>{s.subtitle}</p>
                <p style={{fontWeight:800,fontSize:'0.98rem',color:'#0F172A',margin:0,
                  fontFamily:"'Outfit',sans-serif"}}>{s.label}</p>
              </div>
            </div>
            <button onClick={onCancel} style={{background:'rgba(0,0,0,0.06)',border:'none',
              cursor:'pointer',color:'#64748B',borderRadius:8,width:32,height:32,
              display:'flex',alignItems:'center',justifyContent:'center'}}>
              <X size={16}/>
            </button>
          </div>
          {/* Progress bar */}
          <div style={{background:'rgba(0,0,0,0.08)',borderRadius:99,height:4}}>
            <div style={{height:4,borderRadius:99,background:s.color,
              width:`${progress}%`,transition:'width 0.35s ease'}}/>
          </div>
        </div>

        {/* Body */}
        <div style={{padding:'22px',maxHeight:'58vh',overflowY:'auto'}}>

          {/* ─── Step 0: Rent ─────────────────────────────── */}
          {step === 0 && (
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <p style={{color:'#475569',fontSize:'0.86rem',lineHeight:1.65,margin:0}}>
                The listed rent is{' '}
                <strong style={{color:'#2563EB'}}>Rs. {Number(listedRent).toLocaleString()}/mo</strong>.
                Enter the monthly rent you'd like to offer, or leave it as-is to accept the listed price.
              </p>
              <div>
                <label style={lbl}>Your Proposed Monthly Rent (Rs.) <span style={{color:'#94A3B8',fontWeight:400,textTransform:'none'}}>*</span></label>
                <input type="number" style={inp()} {...focus('#2563EB')}
                  value={rentOffer.proposed}
                  onChange={e => setRent(r => ({...r, proposed: e.target.value}))}
                  placeholder={String(listedRent)}/>
                <p style={{fontSize:'0.71rem',color:'#94A3B8',marginTop:4}}>Leave unchanged to accept the listed rent.</p>
              </div>
              <div>
                <label style={lbl}>Message to Landlord <span style={{color:'#94A3B8',fontWeight:400,textTransform:'none'}}>(optional)</span></label>
                <textarea rows={3} style={{...inp(),...{resize:'none'}}} {...focus('#2563EB')}
                  placeholder="Introduce yourself, share why you're a great tenant..."
                  value={rentOffer.message}
                  onChange={e => setRent(r => ({...r, message: e.target.value}))}/>
              </div>
            </div>
          )}

          {/* ─── Step 1: Security ─────────────────────────── */}
          {step === 1 && (
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <p style={{color:'#475569',fontSize:'0.86rem',lineHeight:1.65,margin:0}}>
                The listed security deposit is{' '}
                <strong style={{color:'#7C3AED'}}>Rs. {Number(listedDeposit).toLocaleString()}</strong>.
                Propose a different amount or custom terms if needed.
              </p>
              <div>
                <label style={lbl}>Your Proposed Security Deposit (Rs.)</label>
                <input type="number" style={inp()} {...focus('#7C3AED')}
                  value={securityOffer.proposed}
                  onChange={e => setSecurity(s => ({...s, proposed: e.target.value}))}
                  placeholder={String(listedDeposit)}/>
                <p style={{fontSize:'0.71rem',color:'#94A3B8',marginTop:4}}>Leave unchanged to accept the listed deposit.</p>
              </div>
              <div>
                <label style={lbl}>Payment Terms / Notes <span style={{color:'#94A3B8',fontWeight:400,textTransform:'none'}}>(optional)</span></label>
                <textarea rows={3} style={{...inp(),...{resize:'none'}}} {...focus('#7C3AED')}
                  placeholder="e.g. I can pay the deposit in two installments over 2 months..."
                  value={securityOffer.message}
                  onChange={e => setSecurity(s => ({...s, message: e.target.value}))}/>
              </div>
            </div>
          )}

          {/* ─── Step 2: Maintenance ──────────────────────── */}
          {step === 2 && (
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <p style={{color:'#475569',fontSize:'0.86rem',lineHeight:1.65,margin:0}}>
                Offer to handle maintenance in exchange for a reduced rent.{' '}
                <strong style={{color:'#059669'}}>Leave blank to skip this offer.</strong>
              </p>
              <div>
                <label style={lbl}>What maintenance will you cover? <span style={{color:'#94A3B8',fontWeight:400,textTransform:'none'}}>(optional)</span></label>
                <textarea rows={3} style={{...inp(),...{resize:'none'}}} {...focus('#059669')}
                  placeholder="e.g. Minor plumbing, lawn care, painting, general repairs..."
                  value={maintOffer.scope}
                  onChange={e => setMaint(m => ({...m, scope: e.target.value}))}/>
              </div>
              <div>
                <label style={lbl}>Rent Reduction Requested (Rs./mo)</label>
                <input type="number" style={inp()} {...focus('#059669')}
                  placeholder="e.g. 5000"
                  value={maintOffer.reduction}
                  onChange={e => setMaint(m => ({...m, reduction: e.target.value}))}/>
              </div>
              <div>
                <label style={lbl}>Additional Notes <span style={{color:'#94A3B8',fontWeight:400,textTransform:'none'}}>(optional)</span></label>
                <textarea rows={2} style={{...inp(),...{resize:'none'}}} {...focus('#059669')}
                  placeholder="Any extra context for the landlord..."
                  value={maintOffer.message}
                  onChange={e => setMaint(m => ({...m, message: e.target.value}))}/>
              </div>
            </div>
          )}

          {/* ─── Step 3: Review ───────────────────────────── */}
          {step === 3 && (
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              <p style={{color:'#475569',fontSize:'0.86rem',lineHeight:1.65,margin:'0 0 6px'}}>
                Review your full offer before submitting to the landlord.
              </p>

              {/* Rent */}
              <div style={{background:'#EFF6FF',border:'1px solid #BFDBFE',borderRadius:12,padding:'12px 16px'}}>
                <p style={{fontSize:'0.63rem',fontWeight:800,color:'#2563EB',
                  textTransform:'uppercase',letterSpacing:'0.09em',margin:'0 0 8px',display:'flex',alignItems:'center',gap:6}}>
                  <Tag size={11}/> Rent Offer
                </p>
                {reviewRow('Monthly Rent', `Rs. ${Number(rentOffer.proposed || listedRent).toLocaleString()}`, '#2563EB')}
                {rentOffer.message && reviewRow('Message', `"${rentOffer.message}"`, '#1E40AF')}
              </div>

              {/* Security */}
              <div style={{background:'#F5F3FF',border:'1px solid #DDD6FE',borderRadius:12,padding:'12px 16px'}}>
                <p style={{fontSize:'0.63rem',fontWeight:800,color:'#7C3AED',
                  textTransform:'uppercase',letterSpacing:'0.09em',margin:'0 0 8px',display:'flex',alignItems:'center',gap:6}}>
                  <ShieldCheck size={11}/> Security Offer
                </p>
                {reviewRow('Deposit', `Rs. ${Number(securityOffer.proposed || listedDeposit).toLocaleString()}`, '#7C3AED')}
                {securityOffer.message && reviewRow('Terms', `"${securityOffer.message}"`, '#6D28D9')}
              </div>

              {/* Maintenance */}
              {maintOffer.scope?.trim() ? (
                <div style={{background:'#F0FDF4',border:'1px solid #BBF7D0',borderRadius:12,padding:'12px 16px'}}>
                  <p style={{fontSize:'0.63rem',fontWeight:800,color:'#059669',
                    textTransform:'uppercase',letterSpacing:'0.09em',margin:'0 0 8px',display:'flex',alignItems:'center',gap:6}}>
                    <Wrench size={11}/> Maintenance Offer
                  </p>
                  {reviewRow('Scope', maintOffer.scope, '#065F46')}
                  {maintOffer.reduction && reviewRow('Rent Reduction', `Rs. ${Number(maintOffer.reduction).toLocaleString()}/mo`, '#059669')}
                </div>
              ) : (
                <div style={{background:'#F8FAFC',border:'1px dashed #CBD5E1',borderRadius:12,padding:'10px 16px',textAlign:'center'}}>
                  <p style={{color:'#94A3B8',fontSize:'0.78rem',fontWeight:600,margin:0}}>
                    No maintenance offer — skipped
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer buttons */}
        <div style={{padding:'16px 22px',borderTop:'1px solid #F1F5F9',
          display:'flex',gap:10,background:'white'}}>
          {step > 0 && (
            <button onClick={() => setStep(s => s - 1)}
              style={{flex:1,padding:'12px',border:'1.5px solid #E2E8F0',borderRadius:12,
                background:'white',color:'#475569',fontWeight:700,fontSize:'0.88rem',
                cursor:'pointer',fontFamily:"'Outfit',sans-serif",display:'flex',
                alignItems:'center',justifyContent:'center',gap:6}}>
              <ChevronLeft size={16}/> Back
            </button>
          )}
          {step < 3 ? (
            <button onClick={() => setStep(s => s + 1)}
              style={{flex:2,padding:'12px',border:'none',borderRadius:12,
                background:s.color,color:'white',fontWeight:700,fontSize:'0.88rem',
                cursor:'pointer',fontFamily:"'Outfit',sans-serif",display:'flex',
                alignItems:'center',justifyContent:'center',gap:6,
                boxShadow:`0 4px 14px ${s.color}40`}}>
              Continue <ChevronRight size={16}/>
            </button>
          ) : (
            <button onClick={() => onSubmit({ rentOffer, securityOffer, maintenanceOffer: maintOffer })}
              disabled={applying}
              style={{flex:2,padding:'12px',border:'none',borderRadius:12,
                background: applying ? '#93C5FD' : '#2563EB',
                color:'white',fontWeight:700,fontSize:'0.88rem',
                cursor: applying ? 'not-allowed' : 'pointer',
                fontFamily:"'Outfit',sans-serif",display:'flex',
                alignItems:'center',justifyContent:'center',gap:8,
                boxShadow:'0 4px 14px rgba(37,99,235,0.35)'}}>
              {applying
                ? <><Loader2 size={16} style={{animation:'spin 1s linear infinite'}}/> Submitting...</>
                : <><Send size={15}/> Submit Full Offer</>}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
function ListingDetailContent() {
  const { id }         = useParams();
  const router         = useRouter();
  const searchParams   = useSearchParams();
  const isViewOnly     = searchParams.get('viewOnly') === 'true';

  const [listing, setListing]               = useState(null);
  const [loading, setLoading]               = useState(true);
  const [applying, setApplying]             = useState(false);
  const [applied, setApplied]               = useState(false);
  const [submissionTime, setSubmissionTime] = useState(null);
  const [currentUser, setCurrentUser]       = useState(null);
  const [saved, setSaved]                   = useState(false);
  const [selectedTourDate, setSelectedTourDate] = useState(0);
  const [tourOffset, setTourOffset]         = useState(0);
  const [showGallery, setShowGallery]       = useState(false);
  const [showWizard, setShowWizard]         = useState(false);

  const tourDates    = getTourDates(10);
  const visibleDates = tourDates.slice(tourOffset, tourOffset + 4);

  useEffect(() => {
    const stored = localStorage.getItem('userInfo');
    const user   = stored ? JSON.parse(stored) : null;
    if (user) setCurrentUser(user);

    const fetchListing = async () => {
      try {
        const { data } = await api.get(`/listings/${id}`);
        setListing(data);
        // Check if this user already submitted an offer
        if (user && data.applications?.length > 0) {
          const existing = data.applications.find(
            a => a.tenant === user._id || a.tenant?._id === user._id
          );
          if (existing) {
            setApplied(true);
            setSubmissionTime(existing.createdAt ? new Date(existing.createdAt) : null);
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchListing();
  }, [id]);

  const handleSubmitOffer = async ({ rentOffer, securityOffer, maintenanceOffer }) => {
    setApplying(true);
    try {
      await api.post(`/listings/${id}/offer`, { rentOffer, securityOffer, maintenanceOffer });
      setApplied(true);
      setSubmissionTime(new Date());
      setShowWizard(false);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to submit offer. Please try again.');
    } finally {
      setApplying(false);
    }
  };

  if (loading) return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <Loader2 style={{animation:'spin 1s linear infinite',color:'#2563EB',width:32,height:32}}/>
    </div>
  );
  if (!listing) return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <p style={{color:'#64748B',fontWeight:600,fontSize:'1.05rem'}}>Listing not found.</p>
    </div>
  );

  const images     = listing.images?.length ? listing.images : [];
  const coverImg   = images[0] || null;   // always images[0] — never changes
  const rent       = listing.financials?.monthlyRent;
  const deposit    = listing.financials?.securityDeposit;
  const address    = [listing.address?.street, listing.address?.city, listing.address?.state].filter(Boolean).join(', ');
  const listedDate = listing.createdAt
    ? new Date(listing.createdAt).toLocaleDateString('en-US',{month:'2-digit',day:'2-digit',year:'2-digit'})
    : '—';

  const breadcrumbs = [
    { label: 'Home',              href: '/' },
    { label: 'Browse',            href: '/browse' },
    { label: listing.address?.city || 'City', href: `/browse?city=${listing.address?.city}` },
    { label: listing.title,       href: null },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap');
        *, body { font-family: 'Plus Jakarta Sans', sans-serif; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .hero-wrapper {
          position: relative; width: 100%; height: 480px; overflow: hidden;
        }
        .hero-bg-img {
          position: absolute; inset: 0; width: 100%; height: 100%;
          object-fit: cover; object-position: center; z-index: 0;
        }
        .hero-overlay {
          position: absolute; inset: 0; z-index: 1;
          background: linear-gradient(180deg, rgba(15,23,42,0.45) 0%, rgba(15,23,42,0.78) 100%);
        }
        .hero-content { position: relative; z-index: 2; }
        .bc-sep   { color: rgba(255,255,255,0.35); margin: 0 5px; font-size: 0.75rem; }
        .bc-link  { color: rgba(255,255,255,0.6); font-size: 0.75rem; font-weight: 500; text-decoration: none; }
        .bc-link:hover { color: white; }
        .bc-last  { color: rgba(255,255,255,0.9); font-size: 0.75rem; font-weight: 600; }
        .stat-chip { display:flex; flex-direction:column; align-items:center; gap:3px; }
        .stat-val  { color:white; font-weight:700; font-size:1.1rem; line-height:1; font-family:'Outfit',sans-serif; }
        .stat-lbl  { color:rgba(255,255,255,0.55); font-size:0.66rem; text-transform:uppercase; letter-spacing:0.05em; font-weight:600; }

        .sticky-panel {
          background:white; border:1px solid #E2E8F0; border-radius:20px;
          overflow:hidden; box-shadow:0 8px 32px rgba(15,23,42,0.12);
          position:sticky; top:88px;
        }
        .info-card {
          background:white; border:1px solid #E2E8F0; border-radius:16px; padding:24px;
        }
        .section-title {
          font-family:'Outfit',sans-serif; font-weight:700; font-size:1.05rem;
          color:#0F172A; margin-bottom:14px; padding-bottom:10px; border-bottom:1px solid #F1F5F9;
        }
        .amenity-chip {
          display:inline-flex; align-items:center; gap:5px;
          background:#F8FAFF; border:1px solid #DBEAFE; color:#1E40AF;
          border-radius:8px; padding:5px 11px; font-size:0.78rem; font-weight:600;
        }
        .tour-date-btn {
          padding:9px 10px; border-radius:11px; border:1.5px solid #E2E8F0;
          cursor:pointer; text-align:center; transition:all 0.2s; background:white; flex:1;
        }
        .tour-date-btn:hover { border-color:#93C5FD; }
        .tour-date-btn.sel { border-color:#2563EB; box-shadow:0 0 0 2px rgba(37,99,235,0.15); }

        .view-photos-btn {
          display:flex; align-items:center; gap:8px;
          background:rgba(0,0,0,0.55); backdrop-filter:blur(8px);
          border:1px solid rgba(255,255,255,0.25); color:white;
          padding:9px 18px; border-radius:10px; font-size:0.82rem; font-weight:700;
          cursor:pointer; transition:background 0.2s; font-family:'Plus Jakarta Sans',sans-serif;
        }
        .view-photos-btn:hover { background:rgba(0,0,0,0.72); }

        .make-offer-btn {
          width:100%; background:#2563EB; color:white; font-weight:700; font-size:0.95rem;
          padding:14px 0; border:none; cursor:pointer; transition:background 0.2s;
          font-family:'Outfit',sans-serif; letter-spacing:0.01em;
        }
        .make-offer-btn:hover { background:#1D4ED8; }
        .make-offer-btn:active { transform:scale(0.99); }
      `}</style>

      {/* Modals */}
      {showGallery && images.length > 0 && (
        <GalleryModal images={images} onClose={() => setShowGallery(false)}/>
      )}
      {showWizard && (
        <OfferWizard
          listing={listing}
          onSubmit={handleSubmitOffer}
          onCancel={() => setShowWizard(false)}
          applying={applying}
        />
      )}

      <main style={{flexGrow:1, paddingTop:64, background:'#F8FAFC'}}>

        {/* ── HERO — always shows cover photo (images[0]) ───────────────────── */}
        <div className="hero-wrapper">
          {coverImg
            ? <img src={coverImg} alt="Property cover" className="hero-bg-img"/>
            : <div className="hero-bg-img" style={{background:'linear-gradient(135deg,#1E3A8A,#2563EB)'}}/>
          }
          <div className="hero-overlay"/>

          {/* Back */}
          <button onClick={() => router.back()} className="hero-content"
            style={{position:'absolute',top:72,left:20,display:'flex',alignItems:'center',gap:6,
              color:'rgba(255,255,255,0.8)',background:'rgba(0,0,0,0.3)',backdropFilter:'blur(8px)',
              border:'1px solid rgba(255,255,255,0.15)',padding:'7px 14px',borderRadius:10,
              fontSize:'0.82rem',fontWeight:600,cursor:'pointer',transition:'all 0.2s'}}>
            <ArrowLeft size={15}/> Back
          </button>

          {/* View Photos button — bottom-right of hero */}
          {images.length > 0 && (
            <button className="view-photos-btn hero-content"
              style={{position:'absolute',bottom:20,right:20}}
              onClick={() => setShowGallery(true)}>
              <Images size={15}/>
              View all {images.length} photo{images.length !== 1 ? 's' : ''}
            </button>
          )}

          {/* Hero content */}
          <div className="hero-content" style={{
            position:'absolute',bottom:0,left:0,right:0,padding:'0 24px 28px',
          }}>
            <div style={{maxWidth:1200,margin:'0 auto'}}>

              {/* Breadcrumbs */}
              <div style={{display:'flex',alignItems:'center',flexWrap:'wrap',gap:2,marginBottom:14}}>
                {breadcrumbs.map((b, i) => (
                  <span key={i} style={{display:'flex',alignItems:'center'}}>
                    {i > 0 && <span className="bc-sep">›</span>}
                    {b.href ? <a href={b.href} className="bc-link">{b.label}</a>
                             : <span className="bc-last">{b.label}</span>}
                  </span>
                ))}
              </div>

              <div style={{display:'flex',flexWrap:'wrap',alignItems:'flex-end',justifyContent:'space-between',gap:16}}>
                <div style={{flex:1,minWidth:280}}>
                  <h1 style={{fontFamily:"'Outfit',sans-serif",fontWeight:800,
                    fontSize:'clamp(1.6rem,3vw,2.5rem)',color:'white',
                    lineHeight:1.1,marginBottom:18,letterSpacing:'-0.02em'}}>
                    {listing.title}
                  </h1>

                  {/* Stats */}
                  <div style={{display:'flex',flexWrap:'wrap',gap:20,alignItems:'center'}}>
                    <div className="stat-chip">
                      <span style={{color:'rgba(255,255,255,0.7)',marginBottom:2}}><Bed size={16}/></span>
                      <span className="stat-val">{listing.specs?.bedrooms ?? '—'}</span>
                      <span className="stat-lbl">Bed</span>
                    </div>
                    <div className="stat-chip">
                      <span style={{color:'rgba(255,255,255,0.7)',marginBottom:2}}><Bath size={16}/></span>
                      <span className="stat-val">{listing.specs?.bathrooms ?? '—'}</span>
                      <span className="stat-lbl">Bath</span>
                    </div>
                    <div className="stat-chip">
                      <span style={{color:'rgba(255,255,255,0.7)',marginBottom:2}}><SquareCode size={16}/></span>
                      <span className="stat-val">{listing.specs?.sizeSqFt || '—'}</span>
                      <span className="stat-lbl">Sq Ft</span>
                    </div>
                    <div className="stat-chip">
                      <span style={{color:'rgba(255,255,255,0.7)',marginBottom:2}}><ShieldCheck size={16}/></span>
                      <span className="stat-val" style={{fontSize:'0.82rem'}}>Rs. {deposit?.toLocaleString() || '—'}</span>
                      <span className="stat-lbl">Deposit</span>
                    </div>
                    <div style={{width:1,height:32,background:'rgba(255,255,255,0.15)'}}/>
                    {/* Real view count from DB */}
                    <span style={{display:'flex',alignItems:'center',gap:5,
                      color:'rgba(255,255,255,0.65)',fontSize:'0.75rem',fontWeight:600}}>
                      <Eye size={13}/>
                      {(listing.views ?? 0).toLocaleString()} view{listing.views !== 1 ? 's' : ''}
                    </span>
                    <span style={{display:'flex',alignItems:'center',gap:5,
                      color:'rgba(255,255,255,0.65)',fontSize:'0.75rem',fontWeight:600}}>
                      <Clock size={13}/> Listed {listedDate}
                    </span>
                  </div>
                </div>

                {/* Address pill */}
                <div style={{
                  background:'rgba(255,255,255,0.1)',backdropFilter:'blur(12px)',
                  border:'1px solid rgba(255,255,255,0.2)',color:'white',
                  borderRadius:40,padding:'8px 18px',fontSize:'0.78rem',fontWeight:500,
                  display:'flex',alignItems:'center',gap:7,flexShrink:0,
                }}>
                  <MapPin size={12} style={{color:'rgba(255,255,255,0.6)',flexShrink:0}}/>
                  {address}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── MAIN CONTENT ──────────────────────────────────────────────────── */}
        <div style={{maxWidth:1200,margin:'0 auto',padding:'28px 20px 60px'}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr',gap:24}}>
            <div style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) 340px',gap:24,alignItems:'start'}}>

              {/* ── LEFT ── */}
              <div style={{display:'flex',flexDirection:'column',gap:18}}>

                {/* Description */}
                {listing.listingDescription && (
                  <div className="info-card">
                    <p className="section-title">About This Property</p>
                    <p style={{color:'#475569',lineHeight:1.8,fontSize:'0.9rem',margin:0}}>
                      {listing.listingDescription}
                    </p>
                  </div>
                )}

                {/* Financials */}
                <div className="info-card">
                  <p className="section-title">Financial Details</p>
                  <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12}}>
                    {[
                      { label:'Monthly Rent',     value:`Rs. ${rent?.toLocaleString()||'—'}`,   color:'#2563EB', bg:'#EFF6FF', border:'#BFDBFE' },
                      { label:'Security Deposit', value:`Rs. ${deposit?.toLocaleString()||'—'}`, color:'#0F172A', bg:'#F8FAFC', border:'#E2E8F0' },
                      { label:'Maintenance Fee',  value:`Rs. ${listing.financials?.maintenanceFee?.toLocaleString()||'0'}`, color:'#0F172A', bg:'#F8FAFC', border:'#E2E8F0' },
                    ].map(f => (
                      <div key={f.label} style={{background:f.bg,border:`1px solid ${f.border}`,borderRadius:12,padding:'14px 16px'}}>
                        <p style={{color:'#64748B',fontSize:'0.68rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.05em',margin:'0 0 6px'}}>{f.label}</p>
                        <p style={{color:f.color,fontWeight:800,fontSize:'1.1rem',fontFamily:"'Outfit',sans-serif",margin:0}}>{f.value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Amenities */}
                {listing.amenities?.length > 0 && (
                  <div className="info-card">
                    <p className="section-title">Amenities</p>
                    <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
                      {listing.amenities.map((a, i) => (
                        <span key={i} className="amenity-chip">
                          <CheckCircle size={12}/> {a}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Listed By */}
                <div className="info-card">
                  <p className="section-title">Listed By</p>
                  <div style={{display:'flex',alignItems:'center',gap:14}}>
                    <div style={{width:48,height:48,borderRadius:'50%',flexShrink:0,
                      background:'linear-gradient(135deg,#2563EB,#60A5FA)',
                      display:'flex',alignItems:'center',justifyContent:'center',
                      color:'white',fontWeight:700,fontSize:'1.1rem',fontFamily:"'Outfit',sans-serif"}}>
                      {(listing.landlord?.name || 'L')[0].toUpperCase()}
                    </div>
                    <div>
                      <p style={{fontWeight:700,color:'#0F172A',fontSize:'0.95rem',margin:0}}>{listing.landlord?.name || 'Landlord'}</p>
                      <div style={{display:'flex',alignItems:'center',gap:5,marginTop:4}}>
                        <ShieldCheck size={13} style={{color:'#22C55E'}}/>
                        <span style={{color:'#16A34A',fontSize:'0.75rem',fontWeight:600}}>Verified Landlord</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ── RIGHT (sticky panel) ── */}
              <div>
                <div className="sticky-panel">

                  {/* Save + Price */}
                  <div style={{padding:'20px 20px 16px'}}>
                    <div style={{display:'flex',justifyContent:'flex-end',marginBottom:12}}>
                      <button onClick={() => setSaved(!saved)} style={{
                        display:'flex',alignItems:'center',gap:6,color:saved?'#EF4444':'#64748B',
                        fontWeight:600,fontSize:'0.8rem',background:'none',border:'none',cursor:'pointer',
                      }}>
                        <Heart size={15} fill={saved?'#EF4444':'none'}/> {saved?'Saved':'Save'}
                      </button>
                    </div>
                    <div style={{textAlign:'center',marginBottom:12}}>
                      <p style={{color:'#94A3B8',fontSize:'0.72rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.07em',margin:'0 0 4px'}}>Monthly Rent</p>
                      <p style={{fontFamily:"'Outfit',sans-serif",fontWeight:800,fontSize:'2rem',color:'#0F172A',lineHeight:1,margin:0}}>
                        Rs. {rent?.toLocaleString() || '—'}
                      </p>
                    </div>
                    <div style={{display:'flex',justifyContent:'center',gap:6,marginBottom:4}}>
                      <span style={{color:'#64748B',fontSize:'0.78rem'}}>Availability:</span>
                      <span style={{color:'#16A34A',fontWeight:700,fontSize:'0.78rem'}}>
                        {listing.status === 'vacant' ? 'Available Now' : listing.status}
                      </span>
                    </div>
                  </div>

                  {/* CTA */}
                  {isViewOnly ? (
                    <div style={{padding:'0 20px 20px'}}>
                      <div style={{background:'#EFF6FF',border:'1px solid #BFDBFE',borderRadius:12,padding:16,textAlign:'center'}}>
                        <FileText size={20} style={{color:'#2563EB',margin:'0 auto 8px'}}/>
                        <p style={{fontSize:'0.85rem',fontWeight:600,color:'#1E40AF',margin:0}}>
                          You have an active lease for this property.
                        </p>
                      </div>
                    </div>
                  ) : applied ? (
                    <div style={{padding:'0 20px 20px'}}>
                      <div style={{background:'#F0FDF4',border:'1px solid #BBF7D0',borderRadius:12,padding:16,textAlign:'center'}}>
                        <CheckCircle size={26} style={{color:'#22C55E',margin:'0 auto 8px'}}/>
                        <p style={{fontWeight:800,color:'#15803D',fontSize:'1rem',margin:'0 0 4px',fontFamily:"'Outfit',sans-serif"}}>
                          Offer Submitted!
                        </p>
                        <p style={{color:'#4ADE80',fontSize:'0.78rem',fontWeight:600,margin:0}}>
                          Rent · Security · Maintenance offers sent
                        </p>
                        {submissionTime && (
                          <p style={{color:'#94A3B8',fontSize:'0.7rem',marginTop:10}}>
                            {submissionTime.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
                          </p>
                        )}
                      </div>
                    </div>
                  ) : currentUser?.role === 'tenant' || !currentUser ? (
                    <div style={{padding:'0 0 0'}}>
                      <div style={{padding:'0 20px 14px'}}>
                        <div style={{background:'#F8FAFC',borderRadius:12,padding:'10px 14px',
                          border:'1px solid #E2E8F0',display:'flex',flexDirection:'column',gap:6}}>
                          {[
                            {icon:Tag,       label:'Propose your rent',          color:'#2563EB'},
                            {icon:ShieldCheck,label:'Propose security deposit',  color:'#7C3AED'},
                            {icon:Wrench,    label:'Offer maintenance deal',     color:'#059669'},
                          ].map(item => (
                            <div key={item.label} style={{display:'flex',alignItems:'center',gap:8}}>
                              <item.icon size={13} style={{color:item.color,flexShrink:0}}/>
                              <span style={{color:'#475569',fontSize:'0.78rem',fontWeight:600}}>{item.label}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <button className="make-offer-btn"
                        onClick={() => currentUser ? setShowWizard(true) : router.push(`/login?redirect=/browse/${id}`)}>
                        {currentUser ? 'Make an Offer' : 'Login to Make an Offer'}
                      </button>
                    </div>
                  ) : (
                    // Landlord/admin viewing — no offer button
                    <div style={{padding:'0 20px 20px'}}>
                      <div style={{background:'#FFF7ED',border:'1px solid #FED7AA',borderRadius:12,padding:14,textAlign:'center'}}>
                        <p style={{color:'#C2410C',fontSize:'0.82rem',fontWeight:600,margin:0}}>Offers can only be submitted by tenants.</p>
                      </div>
                    </div>
                  )}

                  {/* Tour Date */}
                  <div style={{borderTop:'1px solid #F1F5F9',padding:20}}>
                    <p style={{textAlign:'center',fontWeight:700,color:'#0F172A',fontSize:'0.88rem',
                      marginBottom:14,fontFamily:"'Outfit',sans-serif",display:'flex',
                      alignItems:'center',justifyContent:'center',gap:8}}>
                      <Home size={15} style={{color:'#2563EB'}}/> Schedule a Tour
                    </p>
                    <div style={{display:'flex',alignItems:'center',gap:5}}>
                      <button onClick={() => setTourOffset(o => Math.max(0, o-1))} disabled={tourOffset===0}
                        style={{background:'none',border:'1.5px solid #E2E8F0',borderRadius:8,
                          width:28,height:28,display:'flex',alignItems:'center',justifyContent:'center',
                          cursor: tourOffset===0?'not-allowed':'pointer',color:'#64748B',flexShrink:0}}>
                        <ChevronLeft size={13}/>
                      </button>
                      <div style={{display:'flex',gap:4,flex:1}}>
                        {visibleDates.map((d, i) => (
                          <button key={i}
                            onClick={() => setSelectedTourDate(tourOffset + i)}
                            className={`tour-date-btn ${selectedTourDate === tourOffset + i ? 'sel' : ''}`}>
                            <p style={{fontSize:'0.6rem',color:'#94A3B8',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.05em',margin:0}}>{d.day}</p>
                            <p style={{fontFamily:"'Outfit',sans-serif",fontWeight:800,fontSize:'1rem',
                              color:selectedTourDate===tourOffset+i?'#2563EB':'#0F172A',lineHeight:1.2,margin:'2px 0'}}>{d.num}</p>
                            <p style={{fontSize:'0.6rem',color:'#94A3B8',fontWeight:600,margin:0}}>{d.month}</p>
                          </button>
                        ))}
                      </div>
                      <button onClick={() => setTourOffset(o => Math.min(tourDates.length-4, o+1))}
                        disabled={tourOffset >= tourDates.length-4}
                        style={{background:'none',border:'1.5px solid #E2E8F0',borderRadius:8,
                          width:28,height:28,display:'flex',alignItems:'center',justifyContent:'center',
                          cursor:tourOffset>=tourDates.length-4?'not-allowed':'pointer',color:'#64748B',flexShrink:0}}>
                        <ChevronRight size={13}/>
                      </button>
                    </div>
                    <button style={{
                      width:'100%',marginTop:12,padding:'11px',
                      background:'linear-gradient(135deg,#1D4ED8,#3B82F6)',
                      color:'white',fontWeight:700,fontSize:'0.85rem',
                      border:'none',borderRadius:12,cursor:'pointer',
                      fontFamily:"'Outfit',sans-serif",
                    }}>
                      Schedule Tour
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default function ListingDetailPage() {
  return (
    <div style={{minHeight:'100vh',display:'flex',flexDirection:'column',background:'#F8FAFC'}}>
      <Navbar />
      <Suspense fallback={
        <div style={{flexGrow:1,paddingTop:80,display:'flex',justifyContent:'center',alignItems:'center'}}>
          <Loader2 style={{animation:'spin 1s linear infinite',color:'#2563EB',width:32,height:32}}/>
        </div>
      }>
        <ListingDetailContent />
      </Suspense>
      <Footer />
    </div>
  );
}